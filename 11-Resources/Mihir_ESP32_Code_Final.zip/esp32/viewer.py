"""
EGR314 Team 302 - Camera Frame Viewer (run on your laptop)
Subscribes to TOPIC_CAM_FRAME and reassembles chunked JPEG frames.
Displays them in a live OpenCV window.

Requirements:
    pip install paho-mqtt opencv-python

Usage:
    python viewer.py

Controls:
    q or ESC  - quit
    s         - save current frame as PNG
    c         - send "capture" command (one shot)
    1         - send "stream on"
    0         - send "stream off"
"""

import paho.mqtt.client as mqtt
import base64, json, cv2, numpy as np, ssl, time, os, sys

# ── Edit these to match your config.py ───────────────────────────────────────
MQTT_SERVER   = "your.mqtt.server"   # same as config.py MQTT_SERVER
MQTT_PORT     = 8883
MQTT_USER     = "your_user"
MQTT_PASSWORD = "your_password"

TOPIC_CAM_FRAME  = "egr314/team302/camera/frame"    # match config.py
TOPIC_CAM_STATUS = "egr314/team302/camera/status"
TOPIC_CAM_CMD    = "egr314/team302/camera/cmd"      # same as TOPIC_SUB or dedicated

CA_CERT   = "certs/ca_crt.pem"
CLIENT_CRT= "certs/student_crt.pem"
CLIENT_KEY= "certs/student_key.pem"
# ─────────────────────────────────────────────────────────────────────────────

# Frame reassembly buffer: {seq: {chunk_index: bytes}}
_frame_buf  = {}
_latest_img = None        # most recently decoded OpenCV frame
_save_next  = False
_frame_count= 0

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print('[MQTT]  Connected')
        client.subscribe(TOPIC_CAM_FRAME, qos=0)
        client.subscribe(TOPIC_CAM_STATUS, qos=1)
        print(f'[MQTT]  Subscribed to {TOPIC_CAM_FRAME}')
    else:
        print(f'[MQTT]  Connection failed rc={rc}')

def on_message(client, userdata, message):
    global _latest_img, _save_next, _frame_count, _frame_buf

    topic = message.topic

    if topic == TOPIC_CAM_STATUS:
        print(f'[STATUS]  {message.payload.decode()}')
        return

    if topic != TOPIC_CAM_FRAME:
        return

    try:
        obj = json.loads(message.payload.decode())
    except Exception as e:
        print(f'[WARN]  JSON parse error: {e}')
        return

    seq   = obj['seq']
    chunk = obj['chunk']
    total = obj['total']
    data  = base64.b64decode(obj['data'])

    if seq not in _frame_buf:
        _frame_buf[seq] = {}
    _frame_buf[seq][chunk] = data

    # Check if all chunks arrived
    if len(_frame_buf[seq]) == total:
        jpeg = b''.join(_frame_buf[seq][i] for i in range(total))
        del _frame_buf[seq]

        # Clean up stale partial frames (keep only last 5)
        stale = sorted(_frame_buf.keys())[:-5] if len(_frame_buf) > 5 else []
        for s in stale:
            del _frame_buf[s]

        arr = np.frombuffer(jpeg, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            print(f'[WARN]  Failed to decode frame seq={seq}')
            return

        _latest_img = img
        _frame_count += 1
        print(f'[FRAME]  seq={seq}  {len(jpeg)}B  total_received={_frame_count}')

        if _save_next:
            fname = f'frame_{seq:05d}_{int(time.time())}.png'
            cv2.imwrite(fname, img)
            print(f'[SAVED]  {fname}')
            _save_next = False


def send_cmd(client, cmd: str):
    client.publish(TOPIC_CAM_CMD, cmd, qos=1)
    print(f'[CMD]  Sent: "{cmd}"')


def main():
    global _save_next

    client = mqtt.Client()
    client.username_pw_set(MQTT_USER, MQTT_PASSWORD)

    if os.path.exists(CA_CERT):
        context = ssl.create_default_context(cafile=CA_CERT)
        if os.path.exists(CLIENT_CRT) and os.path.exists(CLIENT_KEY):
            context.load_cert_chain(CLIENT_CRT, CLIENT_KEY)
        client.tls_set_context(context)
    else:
        print('[WARN]  No CA cert found - connecting without TLS')

    client.on_connect = on_connect
    client.on_message = on_message

    client.connect(MQTT_SERVER, MQTT_PORT, 60)
    client.loop_start()

    cv2.namedWindow('EGR314 Camera Feed', cv2.WINDOW_NORMAL)
    cv2.resizeWindow('EGR314 Camera Feed', 640, 480)

    print()
    print('Controls:')
    print('  q / ESC  - quit')
    print('  s        - save current frame')
    print('  c        - capture (single shot)')
    print('  1        - stream on')
    print('  0        - stream off')
    print()

    blank = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.putText(blank, 'Waiting for camera frames...', (80, 240),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (200, 200, 200), 2)

    while True:
        display = _latest_img if _latest_img is not None else blank

        # Overlay frame counter
        overlay = display.copy()
        cv2.putText(overlay, f'Frames: {_frame_count}', (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        cv2.imshow('EGR314 Camera Feed', overlay)

        key = cv2.waitKey(30) & 0xFF
        if key in (ord('q'), 27):   # q or ESC
            break
        elif key == ord('s'):
            _save_next = True
            print('[INFO]  Next frame will be saved')
        elif key == ord('c'):
            send_cmd(client, 'capture')
        elif key == ord('1'):
            send_cmd(client, 'stream on')
        elif key == ord('0'):
            send_cmd(client, 'stream off')

    cv2.destroyAllWindows()
    client.loop_stop()
    client.disconnect()
    print('[INFO]  Viewer closed')


if __name__ == '__main__':
    main()
