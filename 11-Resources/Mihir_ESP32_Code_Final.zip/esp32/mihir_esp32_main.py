"""
EGR314 Team 302 - Wireless Gateway  |  Board ID: M (Mihir Patel)
Daisy-chain: Mihir(M) - Laksh(L) - Raunak(R)
UART: TX=GPIO17  RX=GPIO16

Packet format: AZ <from> <to> <msg_type 2B> <payload 56B> YB  = 64 bytes total
Example Mihir->Raunak: AZ M R <type> <data...> YB
Broadcast uses '*' as destination — all boards process it

LEDs:
  IO41 D1 RX TEST  - blinks on every UART receive
  IO40 D2 TX TEST  - blinks on every UART send / forward
  IO36 D5 MQTT     - blinks on MQTT pub/sub, rapid 5x on error
  IO35 D6 WiFi     - steady ON=connected  OFF=disconnected

Camera (OV5640 on J6 connector):
  Triggered by: MQTT cmd "capture" / "stream on" / "stream off"
                or MSG_BUTTON_EVENT arriving over UART from any board
  Output: JPEG frames chunked to TOPIC_CAM_FRAME as base64 JSON
  Status: TOPIC_CAM_STATUS
  See camera_module.py for full pin map and chunking protocol
"""

import ssl
import json
import time
from mqtt_as.mqtt_as import MQTTClient
from mqtt_as.mqtt_local import config
import uasyncio as asyncio
from machine import UART, Pin
from config import *
import camera_module as cam

# Board IDs — single ASCII characters
MY_ID        = ord('M')   # 0x4D
SENSOR_ID    = ord('L')   # 0x4C  Laksh
ACTUATOR_ID  = ord('R')   # 0x52  Raunak
BROADCAST_ID = ord('*')   # 0x2A  all boards

# Packet framing — prefix AZ, suffix YB
HEADER     = bytes([0x41, 0x5A])   # 'A' 'Z'
FOOTER     = bytes([0x59, 0x42])   # 'Y' 'B'
PACKET_LEN = 64

# Message types
MSG_MOTOR_SPEED    = 0x0001
MSG_SENSOR_REQUEST = 0x0002
MSG_SENSOR_DATA    = 0x0003
MSG_MOTOR_TELEM    = 0x0004
MSG_EMERGENCY_STOP = 0x0005
MSG_ERROR_CODE     = 0x0006
MSG_ERROR_MSG      = 0x0007
MSG_SYSTEM_STATUS  = 0x0008
MSG_BUTTON_EVENT   = 0x0043
MSG_ACK            = 0x00FF

SEND_INTERVAL_MS = 500

# UART
uart         = UART(2, baudrate=9600, tx=17, rx=16)
buf          = bytearray()
last_sent_ms = 0

# LEDs - direct Pin objects matching schematic
led_rx   = Pin(41, Pin.OUT)
led_tx   = Pin(40, Pin.OUT)
led_mqtt = Pin(36, Pin.OUT)
led_wifi = Pin(35, Pin.OUT)

led_rx.value(0)
led_tx.value(0)
led_mqtt.value(0)
led_wifi.value(0)

# Tracks wifi state so estop_flash() can restore D6 after flashing
_wifi_up = False

# ── LED helpers ───────────────────────────────────────────────────────────────

async def blink_tx():
    led_tx.value(1)
    await asyncio.sleep_ms(100)
    led_tx.value(0)

async def blink_rx():
    led_rx.value(1)
    await asyncio.sleep_ms(100)
    led_rx.value(0)

async def blink_mqtt():
    led_mqtt.value(1)
    await asyncio.sleep_ms(100)
    led_mqtt.value(0)

async def estop_flash():
    for _ in range(3):
        led_tx.value(1); led_rx.value(1)
        led_mqtt.value(1); led_wifi.value(1)
        await asyncio.sleep_ms(200)
        led_tx.value(0); led_rx.value(0)
        led_mqtt.value(0); led_wifi.value(0)
        await asyncio.sleep_ms(200)
    led_wifi.value(1 if _wifi_up else 0)

async def error_flash():
    for _ in range(5):
        led_mqtt.value(1)
        await asyncio.sleep_ms(80)
        led_mqtt.value(0)
        await asyncio.sleep_ms(80)

# ── Packet helpers ────────────────────────────────────────────────────────────

def build_packet(dest_id: int, msg_type: int, data: bytes) -> bytes:
    assert len(data) <= 56, "Payload too long"
    clean = bytearray(data)
    for i in range(len(clean) - 1):
        if clean[i:i+2] == b'\x41\x5A' or clean[i:i+2] == b'\x59\x42':
            clean[i] = 0x00
    payload = bytearray([msg_type >> 8, msg_type & 0xFF])
    payload += bytearray(clean)
    while len(payload) < 58:
        payload += b'\x00'
    return HEADER + bytes([MY_ID, dest_id]) + bytes(payload) + FOOTER

def uart_send(packet: bytes):
    global last_sent_ms
    while time.ticks_diff(time.ticks_ms(), last_sent_ms) < SEND_INTERVAL_MS:
        time.sleep_ms(1)
    assert len(packet) == PACKET_LEN
    uart.write(packet)
    last_sent_ms = time.ticks_ms()
    asyncio.create_task(blink_tx())

def send_ack(dest_id: int, msg_type: int):
    data = bytes([msg_type >> 8, msg_type & 0xFF])
    pkt  = build_packet(dest_id, MSG_ACK, data)
    uart_send(pkt)
    print(f'[UART SENT]  ACK 0x{msg_type:04X} -> {chr(dest_id)}')

def is_valid_packet(frame: bytes) -> bool:
    return (
        len(frame) == PACKET_LEN
        and frame[0:2] == HEADER
        and frame[62:64] == FOOTER
    )

# ── Camera trigger (used by both MQTT callback and UART button handler) ───────

def _handle_camera_command(m: str, client):
    """
    Central camera command dispatcher.
    m    - lowercase stripped command string
    client - active MQTTClient
    """
    if m == 'capture':
        asyncio.create_task(
            cam.cam_single_shot(client, blink_mqtt, blink_tx,
                                lambda s: client.publish(TOPIC_CAM_STATUS, s, qos=1))
        )
        print('[CAM]  Single capture triggered')

    elif m == 'stream on':
        cam.stream_start(client, blink_mqtt, blink_tx)
        print('[CAM]  Streaming started')

    elif m == 'stream off':
        cam.stream_stop()
        print('[CAM]  Streaming stopped')

# ── UART packet processor ─────────────────────────────────────────────────────

def process_packet(pkt, client):
    src      = pkt[2]
    dest     = pkt[3]
    msg_type = (pkt[4] << 8) | pkt[5]
    data     = pkt[6:62]

    if src == MY_ID:
        return  # drop looped-back own packets

    asyncio.create_task(blink_rx())

    if dest != MY_ID and dest != BROADCAST_ID:
        uart.write(pkt)
        asyncio.create_task(blink_tx())
        print(f'[FWD]  AZ{chr(src)}{chr(dest)} 0x{msg_type:04X} YB')
        return

    print(f'\n--- AZ{chr(src)}{chr(dest)} msg=0x{msg_type:04X} ---')

    if msg_type == MSG_SENSOR_DATA:
        imu_tilt    = int.from_bytes(data[0:2], 'big')
        if imu_tilt > 32767: imu_tilt -= 65536
        temperature = int.from_bytes(data[2:4], 'big')
        if temperature > 32767: temperature -= 65536
        hazard   = int.from_bytes(data[4:6], 'big')
        humidity = int.from_bytes(data[6:8], 'big')
        payload = json.dumps({
            'imu_tilt':     imu_tilt / 100,
            'temperature':  temperature / 100,
            'hazard_score': hazard / 100,
            'humidity':     humidity / 100,
            'from':         chr(src)
        })
        print(f'[RCVD]  Sensor Data  tilt={imu_tilt/100} temp={temperature/100}')
        asyncio.create_task(client.publish(TOPIC_TELEMETRY, payload, qos=1))
        asyncio.create_task(blink_mqtt())
        print(f'[MQTT PUB] -> {TOPIC_TELEMETRY}')
        send_ack(src, msg_type)

    elif msg_type == MSG_MOTOR_TELEM:
        direction   = data[0]
        current_rpm = int.from_bytes(data[1:3], 'big')
        dir_str = {0:'STOPPED', 1:'FORWARD', 2:'REVERSE'}.get(direction, 'UNKNOWN')
        payload = json.dumps({
            'direction':   dir_str,
            'current_rpm': current_rpm,
            'from':        chr(src)
        })
        print(f'[RCVD]  Motor Telem  {dir_str} {current_rpm} RPM')
        asyncio.create_task(client.publish(TOPIC_TELEMETRY, payload, qos=1))
        asyncio.create_task(blink_mqtt())
        print(f'[MQTT PUB] -> {TOPIC_TELEMETRY}')
        send_ack(src, msg_type)

    elif msg_type == MSG_EMERGENCY_STOP:
        print(f'[RCVD]  EMERGENCY STOP from {chr(src)}')
        cam.stream_stop()   # safety: stop camera stream on ESTOP
        asyncio.create_task(client.publish(TOPIC_STATUS, 'ESTOP', qos=1))
        asyncio.create_task(blink_mqtt())
        asyncio.create_task(estop_flash())
        print(f'[MQTT PUB] ESTOP -> {TOPIC_STATUS}')
        send_ack(src, msg_type)

    elif msg_type == MSG_ERROR_CODE:
        subsystem  = data[0]
        error_code = data[1]
        payload = json.dumps({'subsystem': chr(subsystem), 'error_code': error_code})
        print(f'[RCVD]  Error code={error_code} from {chr(subsystem)}')
        asyncio.create_task(client.publish(TOPIC_ERROR, payload, qos=1))
        asyncio.create_task(error_flash())
        print(f'[MQTT PUB] -> {TOPIC_ERROR}')
        send_ack(src, msg_type)

    elif msg_type == MSG_ERROR_MSG:
        try:
            msg_str = data[:55].decode('utf-8').rstrip('\x00')
        except:
            msg_str = 'decode error'
        print(f'[RCVD]  Error msg: "{msg_str}"')
        asyncio.create_task(client.publish(TOPIC_ERROR, msg_str, qos=1))
        asyncio.create_task(error_flash())
        print(f'[MQTT PUB] -> {TOPIC_ERROR}')
        send_ack(src, msg_type)

    elif msg_type == MSG_SYSTEM_STATUS:
        status_code = data[0]
        status_str  = {0:'IDLE', 1:'RUNNING', 2:'WARNING', 3:'ERROR', 4:'ESTOP'}.get(status_code, 'UNKNOWN')
        print(f'[RCVD]  System Status: {status_str} from {chr(src)}')
        asyncio.create_task(client.publish(TOPIC_STATUS, f'status={status_str} from={chr(src)}', qos=1))
        asyncio.create_task(blink_mqtt())
        print(f'[MQTT PUB] -> {TOPIC_STATUS}')

    elif msg_type == MSG_BUTTON_EVENT:
        btn_num = data[0]
        print(f'[RCVD]  Button {btn_num} from HMI {chr(src)}')

        # Button 1 = capture, Button 2 = stream on, Button 3 = stream off
        # All other buttons retain original camera_capture broadcast behaviour
        if btn_num == 1:
            _handle_camera_command('capture', client)
        elif btn_num == 2:
            _handle_camera_command('stream on', client)
        elif btn_num == 3:
            _handle_camera_command('stream off', client)
        else:
            asyncio.create_task(client.publish(TOPIC_STATUS, f'camera_capture btn={btn_num}', qos=1))

        asyncio.create_task(blink_mqtt())
        print(f'[MQTT PUB] -> {TOPIC_STATUS}')
        send_ack(src, msg_type)

    elif msg_type == MSG_ACK:
        acked = (data[0] << 8) | data[1]
        print(f'[RCVD]  ACK 0x{acked:04X} from {chr(src)}')

    else:
        print(f'[RCVD]  Unknown msg 0x{msg_type:04X} -- ignoring')

    print('---\n')

# ── UART receive loop ─────────────────────────────────────────────────────────

def receive_loop(client):
    global buf
    if uart.any():
        buf += uart.read(uart.any())

    while len(buf) >= PACKET_LEN:
        start = -1
        for i in range(len(buf) - 1):
            if buf[i] == 0x41 and buf[i+1] == 0x5A:
                start = i; break
        if start == -1:
            buf = bytearray(); return
        if start > 0:
            buf = buf[start:]
        if len(buf) < PACKET_LEN:
            return
        frame = bytes(buf[:PACKET_LEN])
        if is_valid_packet(frame):
            process_packet(frame, client)
            buf = buf[PACKET_LEN:]
        else:
            buf = buf[1:]

# ── MQTT subscription callback ────────────────────────────────────────────────

def sub_cb(topic, msg, retained):
    m = msg.decode().strip().lower()
    print(f'\n[MQTT RCVD]  "{m}"')
    asyncio.create_task(blink_mqtt())

    def _send_motor(direction, rpm):
        rpm  = max(0, min(2300, rpm))
        data = bytes([direction, (rpm >> 8) & 0xFF, rpm & 0xFF])
        uart_send(build_packet(ACTUATOR_ID, MSG_MOTOR_SPEED, data))
        dir_str = {1:'FORWARD', 2:'REVERSE', 0:'STOP'}[direction]
        print(f'[UART SENT]  AZM R 0x0001 {dir_str} {rpm} RPM YB')

    # ── Camera commands ────────────────────────────────────────────────────
    # "capture"           - single JPEG snapshot -> TOPIC_CAM_FRAME
    # "stream on"         - start continuous JPEG stream
    # "stream off"        - stop stream
    if m in ('capture', 'stream on', 'stream off'):
        _handle_camera_command(m, sub_cb._client)

    # ── Motor commands ─────────────────────────────────────────────────────
    elif m.startswith('forward'):
        parts = m.split()
        rpm   = int(parts[1]) if len(parts) > 1 else 500
        _send_motor(1, rpm)

    elif m.startswith('reverse'):
        parts = m.split()
        rpm   = int(parts[1]) if len(parts) > 1 else 500
        _send_motor(2, rpm)

    elif 'stop' in m or 'estop' in m:
        cam.stream_stop()   # stop stream on any stop command
        uart_send(build_packet(BROADCAST_ID, MSG_EMERGENCY_STOP, bytes([MY_ID])))
        print(f'[UART SENT]  AZM* ESTOP YB')
        asyncio.create_task(estop_flash())

    elif m.startswith('setpoint'):
        parts    = m.split()
        try:    val = int(parts[1])
        except: val = 0
        val = max(-2300, min(2300, val))
        direction = 1 if val > 0 else (2 if val < 0 else 0)
        rpm = abs(val)
        _send_motor(direction, rpm)
        asyncio.create_task(sub_cb._client.publish(TOPIC_STATUS, f'setpoint dir={direction} rpm={rpm}', qos=1))
        asyncio.create_task(blink_mqtt())

    elif m.startswith('sensor'):
        parts     = m.split()
        sensor_id = max(1, min(3, int(parts[1]) if len(parts) > 1 else 1))
        uart_send(build_packet(SENSOR_ID, MSG_SENSOR_REQUEST, bytes([sensor_id])))
        print(f'[UART SENT]  AZML sensor_req id={sensor_id} YB')

    elif 'status' in m:
        uart_send(build_packet(BROADCAST_ID, MSG_SYSTEM_STATUS, bytes([0x01])))
        print(f'[UART SENT]  AZM* system_status YB')

    else:
        print(f'[MQTT RCVD]  Unknown command. Available commands:')
        print(f'             forward <rpm>    e.g. "forward 500"')
        print(f'             reverse <rpm>    e.g. "reverse 300"')
        print(f'             stop             emergency stop all boards')
        print(f'             setpoint <rpm>   e.g. "setpoint 400"')
        print(f'             sensor <id>      e.g. "sensor 1"')
        print(f'             status')
        print(f'             capture          take one photo')
        print(f'             stream on        start JPEG stream')
        print(f'             stream off       stop JPEG stream')

# ── Async tasks ───────────────────────────────────────────────────────────────

async def heartbeat_task(client):
    count = 0
    while True:
        await asyncio.sleep(5)
        await client.publish(TOPIC_HB, f'heartbeat {count}', qos=1)
        asyncio.create_task(blink_mqtt())
        print(f'[HB]  heartbeat {count}')
        count += 1

async def periodic_task(client):
    await asyncio.sleep(5)
    while True:
        uart_send(build_packet(SENSOR_ID, MSG_SENSOR_REQUEST, bytes([0x01])))
        print(f'[PERIODIC]  AZML sensor_req YB')
        await asyncio.sleep(15)
        uart_send(build_packet(BROADCAST_ID, MSG_SYSTEM_STATUS, bytes([0x01])))
        print(f'[PERIODIC]  AZM* system_status YB')
        await asyncio.sleep(15)

async def uart_task(client):
    while True:
        receive_loop(client)
        await asyncio.sleep_ms(10)

async def wifi_han(state):
    global _wifi_up
    _wifi_up = state
    led_wifi.value(1 if state else 0)
    print(f'[WiFi]  {"Connected" if state else "Disconnected"}')
    if not state:
        cam.stream_stop()   # stop camera stream on WiFi loss
        uart.write(build_packet(BROADCAST_ID, MSG_EMERGENCY_STOP, bytes([MY_ID])))
        print(f'[FAILSAFE]  WiFi lost -> AZM* ESTOP YB')
        asyncio.create_task(estop_flash())
    await asyncio.sleep(1)

async def conn_han(client):
    await client.subscribe(TOPIC_SUB, 1)
    await client.subscribe(TOPIC_CAM_CMD, 1)   # subscribe to camera command topic
    asyncio.create_task(blink_mqtt())
    print(f'[MQTT]  Subscribed to {TOPIC_SUB}')
    print(f'[MQTT]  Subscribed to {TOPIC_CAM_CMD}')

async def main(client):
    # Initialise camera before connecting
    if not cam.cam_init():
        print('[WARN]  Camera unavailable - continuing without camera')

    try:
        await client.connect()
    except OSError:
        print('[MQTT] Connection failed')
        return

    # Store client ref in sub_cb for camera commands
    sub_cb._client = client

    asyncio.create_task(heartbeat_task(client))
    asyncio.create_task(uart_task(client))
    asyncio.create_task(periodic_task(client))

    while True:
        await asyncio.sleep(1)

# ── MQTT / WiFi config ────────────────────────────────────────────────────────

config['server']              = MQTT_SERVER
config['ssid']                = WIFI_SSID
config['wifi_pw']             = WIFI_PASSWORD
config['ssl']                 = True
config['user']                = MQTT_USER
config['password']            = MQTT_PASSWORD
config['subs_cb']             = sub_cb
config['wifi_coro']           = wifi_han
config['connect_coro']        = conn_han
config['clean']               = True
config['time_server']         = MQTT_SERVER
config['time_server_timeout'] = 10

with open('certs/student_key.pem', 'rb') as f:
    key_data = f.read()
with open('certs/student_crt.pem', 'rb') as f:
    cert_data = f.read()
with open('certs/ca_crt.pem', 'rb') as f:
    ca_data = f.read()

config['ssl_params'] = {
    "cert":            cert_data,
    "key":             key_data,
    "cadata":          ca_data,
    "server_hostname": MQTT_SERVER,
    "cert_reqs":       ssl.CERT_REQUIRED
}

MQTTClient.DEBUG = True
client = MQTTClient(config)

try:
    asyncio.run(main(client))
finally:
    client.close()
    asyncio.new_event_loop()
