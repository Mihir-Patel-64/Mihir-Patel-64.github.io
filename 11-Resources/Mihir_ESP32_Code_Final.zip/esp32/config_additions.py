# ── Add these lines to your existing config.py ───────────────────────────────
# Camera MQTT topics
# These follow the same base topic structure as your existing topics.
# Adjust the base path to match whatever prefix you already use.

TOPIC_CAM_CMD    = "egr314/team302/camera/cmd"     # viewer/dashboard -> ESP32 (subscribe)
TOPIC_CAM_FRAME  = "egr314/team302/camera/frame"   # ESP32 -> viewer  (publish, QoS 0)
TOPIC_CAM_STATUS = "egr314/team302/camera/status"  # ESP32 -> broker  (publish, QoS 1)
