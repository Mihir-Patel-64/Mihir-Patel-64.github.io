"""
EGR314 Team 302 - Camera Module  |  Board ID: M (Mihir Patel) / Subsystem: C (Camera)
OV5640 connected to ESP32-S3 via J6 connector (see schematic)

Camera pin mapping from schematic (J6 Conn_02x09_Odd_Even):
  PWDN   -> IO10    RESET  -> IO15
  VSYNC  -> IO4     HREF   -> IO23
  PCLK   -> IO20    SCL    -> IO22
  SDA    -> IO5
  D9     -> IO19    D8     -> IO18
  D7     -> IO6     D6     -> IO7
  D5     -> IO8     D4     -> IO9
  D3     -> IO11    D2     -> IO12

MQTT camera topics (defined in config.py):
  TOPIC_CAM_CMD    - subscribe: "capture", "stream on", "stream off"
  TOPIC_CAM_FRAME  - publish:  chunked JPEG bytes (base64, with sequence header)
  TOPIC_CAM_STATUS - publish:  camera health / frame metadata

Packet framing note:
  Camera frames are too large for the 64-byte UART packet format, so they go
  directly over MQTT. However, log messages and trigger events still use the
  AZ<src><dst> ... YB format where src='M' dst='*' for broadcast status.

Frame chunking format over MQTT (TOPIC_CAM_FRAME):
  Each message is a JSON object:
  {
    "seq":   <frame sequence number>,
    "chunk": <chunk index, 0-based>,
    "total": <total chunks for this frame>,
    "data":  "<base64-encoded JPEG bytes for this chunk>"
  }
  Receiver reassembles chunks in order and decodes the full JPEG.
  Chunk size: 4096 bytes of raw JPEG -> ~5460 base64 chars per MQTT message.
"""

import camera          # MicroPython esp32-camera module (must be in firmware)
import uasyncio as asyncio
import ujson as json
import ubinascii
import time

# ── Pin assignments from schematic ──────────────────────────────────────────
CAM_PWDN  = 10
CAM_RESET = 15
CAM_VSYNC = 4
CAM_HREF  = 23
CAM_PCLK  = 20
CAM_SCL   = 22
CAM_SDA   = 5
CAM_D2    = 12
CAM_D3    = 11
CAM_D4    = 9
CAM_D5    = 8
CAM_D6    = 7
CAM_D7    = 6
CAM_D8    = 18
CAM_D9    = 19

# ── Camera configuration ─────────────────────────────────────────────────────
# FRAMESIZE options (smaller = faster MQTT delivery):
#   camera.FRAME_96X96, camera.FRAME_QQVGA (160x120), camera.FRAME_QVGA (320x240)
#   camera.FRAME_VGA (640x480), camera.FRAME_SVGA (800x600) -- use only if WiFi is strong
CAM_FRAMESIZE = camera.FRAME_QVGA   # 320x240 -- good balance for MQTT
CAM_QUALITY   = 12                  # JPEG quality 10-63; lower = better quality

CHUNK_SIZE    = 4096                # bytes of JPEG per MQTT chunk
STREAM_FPS    = 2                   # max frames/sec in streaming mode (keep MQTT happy)

# ── Module state ─────────────────────────────────────────────────────────────
_cam_ready    = False
_streaming    = False
_frame_seq    = 0


def cam_init() -> bool:
    """
    Initialise the OV5640 camera.
    Returns True on success, False on failure.
    Call once at startup before any capture.
    """
    global _cam_ready
    try:
        camera.init(
            0,                       # camera index (always 0 for single camera)
            format   = camera.JPEG,
            framesize= CAM_FRAMESIZE,
            # Pin assignments
            pwdn     = CAM_PWDN,
            reset    = CAM_RESET,
            sioc     = CAM_SCL,      # SCCB clock = I2C SCL
            siod     = CAM_SDA,      # SCCB data  = I2C SDA
            vsync    = CAM_VSYNC,
            href     = CAM_HREF,
            pclk     = CAM_PCLK,
            d0       = CAM_D2,       # D0 in camera lib = D2 in schematic (bit 2)
            d1       = CAM_D3,
            d2       = CAM_D4,
            d3       = CAM_D5,
            d4       = CAM_D6,
            d5       = CAM_D7,
            d6       = CAM_D8,
            d7       = CAM_D9,       # D7 in camera lib = D9 in schematic (bit 9)
        )
        camera.quality(CAM_QUALITY)
        camera.contrast(0)           # 0 = default
        camera.saturation(0)
        camera.brightness(0)
        camera.flip(0)               # 0 = no flip; set 1 if image is upside-down
        camera.mirror(0)
        _cam_ready = True
        print('[CAM]  OV5640 initialised  QVGA JPEG')
        return True
    except Exception as e:
        print(f'[CAM]  Init failed: {e}')
        _cam_ready = False
        return False


def cam_capture_raw() -> bytes | None:
    """
    Capture a single JPEG frame. Returns raw JPEG bytes or None on failure.
    """
    if not _cam_ready:
        print('[CAM]  Not ready - call cam_init() first')
        return None
    try:
        frame = camera.capture()
        if frame is None or len(frame) == 0:
            print('[CAM]  Empty frame')
            return None
        return bytes(frame)
    except Exception as e:
        print(f'[CAM]  Capture error: {e}')
        return None


async def publish_frame(client, jpeg: bytes, blink_mqtt_fn):
    """
    Chunk a JPEG frame into base64 JSON messages and publish to TOPIC_CAM_FRAME.
    Each chunk is a self-contained JSON object so the subscriber can reassemble
    even if chunks arrive out of order (they won't over a single MQTT connection,
    but defensive design is good practice).

    Args:
        client        - mqtt_as MQTTClient instance
        jpeg          - raw JPEG bytes
        blink_mqtt_fn - coroutine function to blink the MQTT LED
    """
    global _frame_seq
    from config import TOPIC_CAM_FRAME

    total_bytes  = len(jpeg)
    total_chunks = (total_bytes + CHUNK_SIZE - 1) // CHUNK_SIZE
    seq          = _frame_seq
    _frame_seq  += 1

    print(f'[CAM]  Publishing frame seq={seq}  {total_bytes}B  chunks={total_chunks}')

    for i in range(total_chunks):
        chunk_raw  = jpeg[i * CHUNK_SIZE : (i + 1) * CHUNK_SIZE]
        chunk_b64  = ubinascii.b2a_base64(chunk_raw).decode().strip()
        msg = json.dumps({
            'seq':   seq,
            'chunk': i,
            'total': total_chunks,
            'data':  chunk_b64
        })
        await client.publish(TOPIC_CAM_FRAME, msg, qos=0)   # qos=0 for speed
        asyncio.create_task(blink_mqtt_fn())
        await asyncio.sleep_ms(20)   # small gap so broker doesn't get overwhelmed

    print(f'[CAM]  Frame seq={seq} published ({total_chunks} chunks)')


async def cam_single_shot(client, blink_mqtt_fn, blink_tx_fn, publish_status_fn):
    """
    Capture one frame and publish it. Used for on-demand capture triggered by
    MQTT command "capture" or MSG_BUTTON_EVENT from HMI board.
    """
    from config import TOPIC_CAM_STATUS

    if not _cam_ready:
        await client.publish(TOPIC_CAM_STATUS, 'camera_not_ready', qos=1)
        return

    await client.publish(TOPIC_CAM_STATUS, 'capturing', qos=1)
    asyncio.create_task(blink_tx_fn())

    jpeg = cam_capture_raw()
    if jpeg is None:
        await client.publish(TOPIC_CAM_STATUS, 'capture_failed', qos=1)
        return

    meta = json.dumps({
        'event': 'frame',
        'size':  len(jpeg),
        'seq':   _frame_seq
    })
    await client.publish(TOPIC_CAM_STATUS, meta, qos=1)
    await publish_frame(client, jpeg, blink_mqtt_fn)


async def stream_task(client, blink_mqtt_fn, blink_tx_fn):
    """
    Continuous streaming loop. Runs as an asyncio task.
    Stops when _streaming is set to False.
    Respects STREAM_FPS to avoid flooding the MQTT broker.
    """
    global _streaming
    from config import TOPIC_CAM_STATUS

    frame_interval_ms = 1000 // STREAM_FPS
    print(f'[CAM]  Stream started at {STREAM_FPS} fps')
    await client.publish(TOPIC_CAM_STATUS, 'stream_start', qos=1)

    while _streaming:
        t0   = time.ticks_ms()
        jpeg = cam_capture_raw()
        if jpeg:
            asyncio.create_task(blink_tx_fn())
            await publish_frame(client, jpeg, blink_mqtt_fn)
        elapsed = time.ticks_diff(time.ticks_ms(), t0)
        gap     = frame_interval_ms - elapsed
        if gap > 0:
            await asyncio.sleep_ms(gap)

    print('[CAM]  Stream stopped')
    await client.publish(TOPIC_CAM_STATUS, 'stream_stop', qos=1)


def stream_start(client, blink_mqtt_fn, blink_tx_fn):
    """Start the streaming task (call from MQTT callback)."""
    global _streaming
    if _streaming:
        print('[CAM]  Already streaming')
        return
    _streaming = True
    asyncio.create_task(stream_task(client, blink_mqtt_fn, blink_tx_fn))
    print('[CAM]  Stream task launched')


def stream_stop():
    """Stop the streaming loop gracefully."""
    global _streaming
    _streaming = False
